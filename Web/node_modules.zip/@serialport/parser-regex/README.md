See our api docs https://serialport.io/docs/api-parser-regex
