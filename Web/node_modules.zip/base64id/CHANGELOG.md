# [2.0.0](https://github.com/faeldt/base64id/compare/1.0.0...2.0.0) (2019-05-27)


### Code Refactoring

* **buffer:** replace deprecated Buffer constructor usage ([#11](https://github.com/faeldt/base64id/issues/11)) ([ccfba54](https://github.com/faeldt/base64id/commit/ccfba54))


### BREAKING CHANGES

* **buffer:** drop support for Node.js ≤ 4.4.x and 5.0.0 - 5.9.x

See: https://nodejs.org/en/docs/guides/buffer-constructor-deprecation/



