
1.0.1 / 2014-02-17
==================

 * go away decimal point
 * history

1.0.0 / 2014-02-17
==================

 * add jitter option
 * Initial commit
